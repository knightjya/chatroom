package client;

public class ClientRun
{

	public static void main(String[] args)
	{
		new ClientGUI("�ͻ���");
		
	}

}
